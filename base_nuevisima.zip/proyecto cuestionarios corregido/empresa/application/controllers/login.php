<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('Login_model');
	}
public function index(){
		$this->load->view('frontend/login_administrador');
	}
	function ingresar(){
		$email = $this->input->post("email");
		$password= ($this->input->post("password"));
		$resp = $this->Login_model->login($email, $password);
	
		if($resp){
			$data = [
				"id" => $resp->idUsuarios,

				"name" => $resp->nombres,

				"login" => TRUE
			];

			$this->session->set_userdata($data);
			
				
		}
		else{
			echo "error";
			
		}
	}





	function cerrar(){
		$this->session->sess_destroy();
	}
}