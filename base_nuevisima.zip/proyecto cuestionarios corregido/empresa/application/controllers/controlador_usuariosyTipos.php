<?php defined('BASEPATH') OR exit('No direct script access allowed');
	/**
	 * 
	 */
	class Controlador_usuariosyTipos extends CI_Controller
	{
		function __construct(){
			parent:: __construct();
			//$this->load->helper('form');
			//$this->load->model('usuarios_model');
			
		}
		public function index(){
			$this->load->view('frontend/welcome_usuarios');
			
		}


		
		
	}
?>