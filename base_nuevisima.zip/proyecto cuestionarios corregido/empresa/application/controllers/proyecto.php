<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Proyecto extends CI_Controller {
	function __construct(){
		parent:: __construct();
		$this->load->helper('form');
		$this->load->model('proyecto_model');
				$this->load->library(array('form_validation'));


		
	}
	function index(){

	}//index


	function nuevo(){
		$this->load->view('frontend/headers');
		$this->load->view('frontend/formulario');
	}

	function recibirdatos()
	{
		$data = array(
		'nombre'=> $this->input->post('nombre'),
		'estudio'=> $this->input->post('estudio')
		);

$config  =  array ( 
        array ( 
                'field'  =>  'nombre' , 
                'label'  =>  'Nombre ' , 
                'rules'  =>  'required', 
                'errors' =>  array ( 
                        'requered'  =>  'Debe proporcionar el % s.' , )  
        ), 
        array ( 'field'  =>  'estudio' ,
		        'label'  =>  ' Estudio' ,
		        'rules'  =>  'required' ,
		        'errors' =>  array ( 'requered'  =>  'Debe proporcionar el % s.' , )
         )
         
		) ;

		$this ->form_validation->set_rules($config);
		 if ($this->form_validation->run() == FALSE){
				$this->load->view('frontend/headers');
		$this->load->view('frontend/formulario');
	
          }else{
		
		$this->proyecto_model->nuevoParticipante($data);
		$data1['participantes'] =$this->proyecto_model->obtenerParticipantes();
		$this->load->view('frontend/datos',$data1);
			}#fin else


		
	}//fin recIbir datos
	function mostrardatos(){
		$data1['participantes'] =$this->proyecto_model->obtenerParticipantes();
		$this->load->view('frontend/datos',$data1);
	}
	function procesar(){
		$this->load->view('frontend/procesar');
	}
	}//Fin de la clase Proyecto
?> 