<?php defined('BASEPATH') OR exit('No direct script access allowed');
	/**
	 * 
	 */
	class Controlador_usuarios extends CI_Controller
	{
		function __construct(){
			parent:: __construct();
			//$this->load->helper('form');
			$this->load->model('usuarios_model');
			$this->load->library(array('form_validation'));
		}
		public function index(){
			$this->load->view('frontend/ingresa_usuario');
			
		}


		function recibirDatos(){

			$config = array(
				array(
					'field' =>'nombres',
					'label' => 'nombre de usuario',
					'rules' => 'required|alpha_numeric_spaces|min_length[3]|max_length[12]'
				),
				array(
					'field' =>'apellidos',
					'label' => 'apellido de usuario',
					'rules' => 'required|alpha_numeric_spaces|min_length[3]|max_length[12]'
				),
				array(
					'field' =>'email',
					'label' => 'email',
					'rules' => 'required|valid_email',
					'errors' => array(
						'required' => 'el %s es invalido',
				),
			),

		);
			$this->form_validation->set_rules($config);
			if($this->form_validation->run() ==FALSE){
				echo '<script language="javascript">alert("error al insertar un campo");</script>';
				$this->load->view('frontend/ingresa_usuario');
			}else{
				$data = array(
				'nombres' => $this->input->post('nombres'),
				'apellidos' => $this->input->post('apellidos'),
				'email' => $this->input->post('email'),
				'password' => $this->input->post('password'),

			);
			$this->usuarios_model->crearUsuario($data);
			echo '<script language="javascript">alert(" registro insertado con exito");</script>';
			$this->load->view('frontend/ingresa_usuario');
			}
			
		}
		
	}
?>