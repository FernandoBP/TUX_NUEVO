<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Fernando De Jesus Bahena Patricio
 */
class altaEstud_model extends CI_Model{
	function __construct(){
		parent:: __construct();
		$this->load->database();
	}#fin constructor
	function crearEstudio($data){
		$this->db-> insert('Estudios',array(
		'nombreEst'  => $data['nombreEst'],
		'jefeEst' => $data['jefeEst'],
		'areaEst' => $data['areaEst'],
		'tiempoEstim' => $data['tiempoEstim']
		)
	);
	}#fin crear Estudio
}#fin class
?>