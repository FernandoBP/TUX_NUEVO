<?php defined('BASEPATH') OR exit('No direct script access allowed');
	class Usuarios_model extends CI_Model{
		function construct(){
			parent:: __construct();
			$this->load->database();
		}

		function crearUsuario($data){
			$this->db->insert('usuarios',array('nombres' => $data['nombres'],'apellidos' => $data['apellidos'],'email' => $data['email'],'password'=>$data['password'],'tipo'=>$data['tipo']
		));
		}



	function getRoles(){
		$this->db->order_by('Descripcion','asc');
		$roles = $this->db->get('tipousuarios');

		if ($roles->num_rows() > 0){
			return $roles->result();
		}
	}

	}
?>