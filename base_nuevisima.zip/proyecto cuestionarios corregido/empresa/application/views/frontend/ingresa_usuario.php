<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Proyecto TUX</title>
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
  <style type="text/css">
    body {
      padding-top: 60px;
      
    }
    .contenido{
      padding: 10px;
    }
  </style>
</head>
<body>


  <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Tux</a>
        </div>
      >
          <ul class="nav navbar-nav navbar-right">
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <i class="fa fa-user fa-fw"></i> <?= $this->session->userdata('name')?><b class="caret"></b>
                </a>
                <ul class="dropdown-menu">
                  <li><a href="#"><i class="fa fa-user fa-fw"></i>Perfil</a></li>
                  <li><a href="javascript:void(0)" id="cerrar"><i class="fa fa-sign-out fa-fw"></i> Cerrar Sesion</a></li>
                </ul>
              </li>
            </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
  
    <div class="container">
    
    <section class="contenido">
      <div class="row">

        <ul class="nav nav-tabs">
              <li class="active"><a href="#tab1" data-toggle="tab">Registrar</a></li>
           
         
          <div class="tab-content">
              <div class="tab-pane  active" id="tab1">
                <div class="col-lg-4"></div>
                  <div class="col-lg-4 text-center">
                    <h2>Alta de Usuarios</h2>
            
<?= form_open("/controlador_usuarios/recibirdatos") ?>
<?php echo validation_errors(); ?>

<?php
  $nombres = array(
    'name' => 'nombres',
    'placeholder' => 'Escribe tu nombre'
  );
  $apellidos = array(
    'name' => 'apellidos',
    'placeholder' => 'Escribe tu apellido'
  );
  $email = array(
    'name' => 'email',
    'placeholder' => 'Escribe tu email'
  );
 $password = array(
    'name' => 'password',
    'placeholder' => 'Escribe tu password'
  );
 
?>
<?= form_label('Nombres: ', 'nombres') ?> 
<?= form_input($nombres) ?>
<br><br>
<?= form_label('Apellidos: ', 'apellidos') ?>
<?= form_input($apellidos) ?>
<br><br>
<?= form_label('Email: ', 'email') ?>
<?= form_input($email) ?>
<br><br>
<?= form_label('Password: ', 'password') ?>
<?= form_input($password) ?>
<br><br>
<h3 class = "text-center"> <?= form_label('Tipo'); ?></h3>
     <div class = "text-center">

<select name= "Descripcion" id="Descripcion">
              <option  value="" selected >Selecciona Estudio</option>
              <?php
                foreach ($Descripcion as $i){
                   echo '<option value="'. $i->Descripcion .'">'. $i->tipousuario .'</option>';
                 } 
              ?>

     <br><br> 


      <br><br>

<?= form_submit('','insertar') ?>
<br><br>

<input type="button" onclick=" location.href='http://localhost/empresa/' " value="Regresar" name="boton" />


<?= form_close() ?>



 
<script src="<?php echo base_url();?>assets/js/jquery-1.11.3.min.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

</body>
</html>
</body>
</html>