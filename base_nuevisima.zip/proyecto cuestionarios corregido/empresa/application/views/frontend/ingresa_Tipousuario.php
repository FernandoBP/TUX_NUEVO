<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Proyecto TUX</title>
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
	<style type="text/css">
		body {
		  padding-top: 60px;
		  
		}
		.contenido{
			padding: 10px;
		}
	</style>
</head>
<body>


	<nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Tux</a>
        </div>
      >
          <ul class="nav navbar-nav navbar-right">
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <i class="fa fa-user fa-fw"></i> <?= $this->session->userdata('name')?><b class="caret"></b>
                </a>
                <ul class="dropdown-menu">
                  <li><a href="#"><i class="fa fa-user fa-fw"></i>Perfil</a></li>
                  <li><a href="javascript:void(0)" id="cerrar"><i class="fa fa-sign-out fa-fw"></i> Cerrar Sesion</a></li>
                </ul>
              </li>
            </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
	
    <div class="container">
		
		<section class="contenido">
			<div class="row">

				<ul class="nav nav-tabs">
			        <li class="active"><a href="#tab1" data-toggle="tab">Registrar</a></li>
			     
			   
			    <div class="tab-content">
			        <div class="tab-pane  active" id="tab1">
			        	<div class="col-lg-4"></div>
			            <div class="col-lg-4 text-center">
			            	<h2>Alta Tipo de Usuarios</h2>
						
<?= form_open("/controlador_Tipousuarios/recibirdatos") ?>
<?php echo validation_errors(); ?>

<?php

	$nombre = array(
		'name' => 'nombre',
		'placeholder' => 'Escribe tu nombre'
	);
	$apellido = array(
		'name' => 'apellido',
		'placeholder' => 'Escribe tu apellido'
	);
	$correo = array(
		'name' => 'correo',
		'placeholder' => 'Escribe tu correo'
	);

	
$tipo = array(
		'name' => 'tipo',
		'placeholder' => 'Escribe tu tipo'
	);



	

?>

 "Administrador,Analista,Encuestador o Administrador de Estudios" 
<br><br>
<?= form_label('Nombre: ', 'nombre') ?> 
<?= form_input($nombre) ?>
<br><br>
<?= form_label('Apellido: ', 'apellido') ?>
<?= form_input($apellido) ?>
<br><br>
<?= form_label('Correo: ', 'correo') ?>
<?= form_input($correo) ?>
<br><br>

<?= form_label('Tipo: ', 'tipo') ?>
<?= form_input($tipo) ?>

<br><br>

<?= form_submit('','insertar') ?>
<br><br>

<input type="button" onclick=" location.href='http://localhost/empresa/' " value="Regresar" name="boton" />


<?= form_close() ?>











 
<script src="<?php echo base_url();?>assets/js/jquery-1.11.3.min.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

</body>
</html>
</body>
</html>