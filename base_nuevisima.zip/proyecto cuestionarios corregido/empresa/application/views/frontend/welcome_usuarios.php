<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Ingresar a cuenta</title>
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">



</head>
<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo">
    <a href="../../index2.html"><b>¿Qué deseas dar de alta? : </b></a>
  </div>
  
  <!-- /.login-logo -->
  

    <div class="social-auth-links text-center">
      

      <a href="<?php echo base_url();?>index.php/controlador_usuarios" class="btn btn-block btn-social btn-google btn-flat"></i> Alta Usuario</a>
      <a href="<?php echo base_url();?>index.php/controlador_Tipousuarios" class="btn btn-block btn-social btn-google btn-flat"></i> Alta tipo Usuario</a>
    </div>
    <!-- /.social-auth-links -->

   
  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url();?>assets/plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="<?php echo base_url();?>assets/plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
</script>
</body>
</html>

