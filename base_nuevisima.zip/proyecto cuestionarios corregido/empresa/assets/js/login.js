$(document).on("ready",main);

function main(){
	$("#login").submit(function(event){
		event.preventDefault();
		$.ajax({
			url:$(this).attr("action"),
			type:$(this).attr( "method"),
			data:$(this).serialize(),
			success:function(resp){
				alert(resp);
				if(resp==="error"){
					alert("Los datos no existen");
				}
				else{

					 alert("Datos del administrador correctos");
					 //$this->load->view('frontend/usuarios');
					// window.location.http="localhost/empresa/usuarios";
					//window.location.href = "http://localhost/empresa/controlador_usuarios";
				//	window.location.href= "http://localhost/empresa/controlador_usuariosyTipos";


				}
			}
		});
	});
}