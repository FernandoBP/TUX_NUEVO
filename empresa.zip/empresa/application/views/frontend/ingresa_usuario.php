<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>TUX</title>
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
  <style type="text/css">
    body {
      padding-top: 60px;
      
    }
    .contenido{
      padding: 10px;
    }
  </style>
</head>
<body>


  <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">SISTEMA TUX</a>
        </div>
       
          <ul class="nav navbar-nav navbar-right">
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <i class="fa fa-user fa-fw"></i> <?= $this->session->userdata('login')?><b class="caret"></b>
                </a>
                <ul class="dropdown-menu">
                  <li><a href="#"><i class="fa fa-user fa-fw"></i>Perfil</a></li>
                  <li><a href="javascript:void(0)" id="cerrar"><i class="fa fa-sign-out fa-fw"></i> Cerrar Sesion</a></li>
                </ul>
              </li>
            </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
  
    <div class="container">
    
    <section class="contenido">
      <div class="row">

        <ul class="nav nav-tabs">
              <li class="active"><a href="#tab1" data-toggle="tab">Registrar</a></li>
              
          </ul>
         
          <div class="tab-content">
              <div class="tab-pane  active" id="tab1">
                <div class="col-lg-4"></div>
                  <div class="col-lg-4 text-center">
                    <h2>ALTA DE USUARIO</h2>
                    <div class="alert alert-danger" id="msg-error" style="text-align:left;">
                  
                  <strong>¡Importante!</strong> Corregir los siguientes errores.
                  <ul class="list-errors"></ul>
              </div>
              <form id="form-create-usuario" style="padding:0px 15px;"class="form-horizontal" role="form" action="<?php base_url();?>usuarios/guardar" method="POST">
                      <div class="form-group">
                        <input type="text" name="nombres" class="form-control" placeholder="Ingrese su Nombre"/>
                      </div>
                      <div class="form-group">
                        <input type="text" name="apellidos" class="form-control" placeholder="Ingrese sus Apellidos  "/>
                      </div>
                      <div class="form-group">
                        <input type="email" name="email" class="form-control" placeholder="Ingrese su Email"/>
                      </div>
                      <div class="form-group">
                        <input type="password" name="password" class="form-control" placeholder="Ingrese su Contraseña"/>
                      </div>
                     


                      <div class="offset1" span5 well">

                   


</div>

                      <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-block" value="Registrar">Registrar</button>
                    </div>
                    

<input type="button" onclick=" location.href='http://localhost/empresa/' " value="Regresar" name="boton" />
                    </form>
                  </div>


              </div>

              <div class="tab-pane fade" id="tab2">

                      
                    
                    </div>
                </div>
                      
                    </div>

                  </div>

              </div>

          </div>
        

      </div>

    </section>


    </div>

 
<script src="<?php echo base_url();?>assets/js/jquery-1.11.3.min.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/js/usuarios.js"></script>
<script src="<?php echo base_url();?>assets/js/login.js"></script>
</body>
</html>
</body>
</html>