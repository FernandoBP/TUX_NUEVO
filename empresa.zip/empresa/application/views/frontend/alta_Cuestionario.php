<?= form_open("adminEncuesta/recibirDatosCuestionario") ?>
<?php
$cuenombre = array('name' => 'nombre','placeholder' => 'Nombre');
$descripcion = array('name' => 'descripcion','placeholder' => 'Descripción del estudio');
$altaEstudio=site_url('adminEncuesta/altaEstudio',NULL);
$altaCuestionario=site_url('adminEncuesta/altaCuestionario',NULL);
$altaReactivo=site_url('adminEncuesta/altaReactivo',NULL);
$cerrarSesion=site_url('login/logout',NULL);
$inicio=site_url('adminEncuesta',NULL);
$rol = $this->session->userdata('rol');
$user = $this->session->userdata('user');
$apell = $this->session->userdata('apellido');
?>
<html>
<meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Proyecto TUX</title>
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
  <style type="text/css">
    body {
      background-color: #00FF00;
      
    }
    .contenido{
      padding: 10px;
    }
    .login{
      border: 1px solid #00FF00;
      
      width: 400px;
      color:white;
      font-weight: bolder;
      top: 50%;
      left: 50%;  
      position: absolute;
      margin-top: -200px;
      margin-left: -200px; 
    }
    .login-title{
      padding: 10px;
      text-align: center;
      background-color: #FFF000;
    }
    form{
      padding: 10px 20px;
      background: #FFF000;
    }
  </style>
</head>
    </div>
  <div class="jumbotron">
    <?php if(isset($error)){?>
      <div class="alert alert-danger alert-dismissible"> 
        <h5 class="text-center"><a class="close" data-dismiss='alert' arial-label="close">&times;</a><strong class="text-center"><?php echo $error; ?></strong></h5><h5 class="text-center"><?= validation_errors('‼ ');?></h5>
      </div>
    <?php } ?>
    <?php if(isset($correcto)){?>
      <div class="alert alert-success alert-dismissible"> 
        <h5 class="text-center"><a class="close" data-dismiss='alert' arial-label="close">&times;</a><strong class="text-center"><?php echo $correcto; ?></strong></h5><h5 class="text-center"><?= validation_errors('☻');?></h5>
      </div>
    <?php } ?>
     <h3 class = "text-center"> <?= form_label('Alta de Cuestionario'); ?></h3>
     <div class = "text-center">
            <select name= "idEstudio" id="idEstudio">
              <option  value="" selected >Selecciona tipo</option>
              <?php
                foreach ($idEstudio as $i){
                   echo '<option value="'. $i->idEstudio .'">'. $i->nombreEst.'</option>';
                 } 
              ?>
            </select></div>





    <h4 class = "text-center">
    <?= form_input($cuenombre) ?></h4>
    <h4 class = "text-center">
    <h5 class = "text-center"><?= form_submit('','Crear cuestionario',"class='btn btn-success'")?></h5>


       </div>
    <!-- /.social-auth-links -->
  <div class="social-auth-links text-center">


<input type="button" onclick=" location.href='http://localhost/empresa/' " value="Regresar" name="boton" />


  </div>

    <?= form_close() ?>
     </div>   
<p>&copy; UAM-I </p>
<!--Insertamos jQuery dependencia de Bootstrap-->
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
     <!--Insertamos el archivo JS compilado y comprimido -->
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</body>
</html>