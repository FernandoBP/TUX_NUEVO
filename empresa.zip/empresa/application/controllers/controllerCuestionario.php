<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ControllerCuestionario extends CI_Controller{
    //put your code here
    public function index(){
      
        		$this->load->database();

        $this->load->view('frontend/alta_Cuestionario');
       

    }
}


