<?php defined('BASEPATH') OR exit('No direct script access allowed');
	/**
	 * 
	 */
	class Controlador_Tipousuarios extends CI_Controller
	{
		function __construct(){
			parent:: __construct();
			//$this->load->helper('form');
			$this->load->model('usuariostipo_model');
			$this->load->library(array('form_validation'));
		}
		public function index(){
			$this->load->view('frontend/ingresa_Tipousuario');
			
		}


		function recibirDatos(){

			$config = array(
				array(
					'field' =>'nombre',
					'label' => 'nombre de usuario',
					'rules' => 'required|alpha_numeric_spaces|min_length[3]|max_length[12]'
				),
				array(
					'field' =>'apellido',
					'label' => 'apellido de usuario',
					'rules' => 'required|alpha_numeric_spaces|min_length[3]|max_length[12]'
				),
				array(
					'field' =>'correo',
					'label' => 'correo',
					'rules' => 'required|valid_email',
					'errors' => array(
						'required' => 'el %s es invalido',
				),



						array(
					'field' =>'tipo',
					'label' => 'tipo de usuario',
					'rules' => 'required|alpha_numeric_spaces|min_length[3]|max_length[12]'
				)
			),

		);
			$this->form_validation->set_rules($config);
			if($this->form_validation->run() ==FALSE){
				echo '<script language="javascript">alert("error al insertar un campo");</script>';
				$this->load->view('frontend/ingresa_Tipousuario');
			}else{
				$data = array(
				'nombre' => $this->input->post('nombre'),
				'apellido' => $this->input->post('apellido'),
				'correo' => $this->input->post('correo'),
				'tipo' => $this->input->post('tipo')
			);
			$this->usuariostipo_model->crearUsuario($data);
			echo '<script language="javascript">alert(" registro insertado con exito");</script>';
			$this->load->view('frontend/ingresa_Tipousuario');
			}
			
		}
		
	}
?>