<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Control_administrador extends CI_Controller{
    //put your code here
    public function index(){
      
        
        $this->load->view('layout/header');
        $this->load->view('layout/menu');
        $this->load->view('staff/Principal');
        $this->load->view('layout/footer');
    }
}


