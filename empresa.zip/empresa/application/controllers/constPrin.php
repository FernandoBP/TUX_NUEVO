<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Fernando De Jesus Bahena Patricio
 */
class ConstPrin extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->model('altaEstud_model');//cargamos el modelo
		$this->load->library(array('form_validation'));
	}

	function index(){
	
	}

	function nuevoEstudio(){
		$this->load->view('frontend/encabezado');
		$this->load->view('frontend/altaEstud');
	}
	function recibirdatos(){
		$data =  array(
			'nombreEst' => $this->input->post('nombreEst'),
			'jefeEst' => $this->input->post('jefeEst'),
			'areaEst' => $this->input->post('areaEst'),
			'tiempoEstim' => $this->input->post('tiempoEstim')
			 );
		#en $config, se configuran las reglas de validaciones por medio de las
		#etiquetas  recibidas en $data
		$config  =  array ( 
        array ( 
                'field'  =>  'nombreEst' , 
                'label'  =>  'Nombre de Estudio' , 
                'rules'  =>  'required', 
                'errors' =>  array ( 
                        'requered'  =>  'Debe proporcionar el % s.' , )  
        ), 
        array ( 'field'  =>  'jefeEst' ,
		        'label'  =>  'Nombre del jese del Estudio' ,
		        'rules'  =>  'required' ,
		        'errors' =>  array ( 'requered'  =>  'Debe proporcionar el % s.' , )
         ),
         array ( 
                'field'  =>  'areaEst' , 
                'label'  =>  'Area de Estudio' , 
                'rules'  =>  'required',
                'errors'  =>  array ( 
                        'requered'  =>  'Debe proporcionar el % s.' , )  
        ),
        array ( 
                'field'  =>  'tiempoEstim' , 
                'label'  =>  'Tiempo del Estudio' , 
                'rules'  =>  'required|alpha_numeric',
                'errors'  =>  array ( 
                        'requered'  =>  'Debe proporcionar el % s.' , )  
        ) 
		) ;

		$this ->form_validation->set_rules($config);
		 if ($this->form_validation->run() == FALSE){
                $this->load->view('frontend/encabezado');
				$this->load->view('frontend/altaEstud');
          }else{
		$this->altaEstud_model->crearEstudio($data);
		$this->load->view('frontend/encabezado');
		$this->load->view('frontend/exitoAltaEstud',$data);
			}#fin else
	}#fin recinir datos
}