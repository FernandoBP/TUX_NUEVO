<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Proyecto_model extends CI_Model {
	function __construct(){
		parent::__construct();
		$this->load->database();
	}//constructor

	function nuevoParticipante($data){
		$this->db->insert('participantes',array(
			'nombrePart' =>$data['nombre'],
			'estudios'=> $data['estudio'])
	);
	}#fin nuevo participante


	function obtenerParticipantes(){
		$query =$this->db->get('participantes');
		if($query->num_rows() > 0) return $query;
		else  return  false;
	}
}//Clase modelo
?>