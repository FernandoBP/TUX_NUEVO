<?php defined('BASEPATH') OR exit('No direct script access allowed');
	class UsuariosTipo_model extends CI_Model{
		function construct(){
			parent:: __construct();
			$this->load->database();
		}

		function crearUsuario($data){
			$this->db->insert('insertartipo',array('nombre' => $data['nombre'],'apellido' => $data['apellido'],'correo' => $data['correo'], 'tipo' => $data['tipo']));
		}
	}
?>